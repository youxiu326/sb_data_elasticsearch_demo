Chrome Extension containing the [Elasticsearch-SQL](https://github.com/NLPchina/elasticsearch-sql) Site.
